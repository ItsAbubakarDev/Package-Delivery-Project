#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <queue>
#include <string>
#include<climits>
using namespace std;

// Structure to represent an edge
class EdgeNeighbour {
public:
    int src, dest, distance;

    EdgeNeighbour(int src, int dest , int distance){
        this->src = src;
        this->dest = dest;
        this->distance = distance;
    }
};

// Function to read the dataset from a file
void readDataset(const string& filename, vector<EdgeNeighbour>& edges) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open the file!" << endl;
        return;
    }

    string line, word;

    // Skip the header line
    getline(file, line);

    // Read data rows
    while (getline(file, line)) {
        istringstream ss(line);
        vector<string> row;

        // Split the line into values using a comma delimiter
        while (getline(ss, word, ',')) {
            row.push_back(word);
        }

        try {
            int src = stoi(row[0]);
            int dest = stoi(row[1]);
            int distance = stoi(row[2]);
            edges.push_back({src, dest,distance});
        } catch (const exception& e) {
            cerr << "Error converting to integer: " << e.what() << endl;
        }
    }

    file.close();
}

// Function to create a graph as an adjacency list
void createGraph(vector<vector<EdgeNeighbour>>& graph, const vector<EdgeNeighbour>& edges) {
    for (const EdgeNeighbour& e : edges) {
        graph[e.src].push_back(e);
    }
}

void findNeighbours(const vector<vector<EdgeNeighbour>>& graph, int src, int vertices) {
    if (src < 0 || src >= vertices) {
        cout << "Invalid source" << endl;
        return;
    }
    
    for (const EdgeNeighbour& e : graph[src]) {
        cout << e.dest << " " << "(distance : "<<e.distance << ") ";
    }
    cout << endl;
}

void findNearestNeighbour(const vector<vector<EdgeNeighbour>>& graph, int src, int vertices){
    if (src < 0 || src >= vertices) {
        cout << "Invalid source" << endl;
        return;
    }
    int nearestDistance = INT_MAX;
    int nearestPoint = -1;  // Track the nearest point
    
    for (const EdgeNeighbour& e : graph[src]) {
        if(e.distance < nearestDistance){
            nearestDistance = e.distance;
            nearestPoint = e.dest;  // Store the destination of the nearest neighbor
        }
    }
    
    if (nearestPoint != -1) {
        cout << "The nearest point from your current location is Point " << nearestPoint 
             << " with distance " << nearestDistance;
    } else {
        cout << "No neighbors found for the current location";
    }
    cout << endl;
}

void getNeighbours() {
    const int vertices = 101; // Adjust based on your graph size
    vector<EdgeNeighbour> edges;
    vector<vector<EdgeNeighbour>> graph(vertices);

    readDataset("GraphdataSet.csv", edges);
    createGraph(graph, edges);

    cout<<"Enter your current location (0 to 100) : ";
    int currentLocation;
    cin>>currentLocation;

    while(currentLocation<0 || currentLocation>100){
        cout<<"Enter valid Location : ";
        cin>>currentLocation;
    }
   findNeighbours(graph, currentLocation, vertices);
}

void getNearestNeighbours() {
    const int vertices = 101; // Adjust based on your graph size
    vector<EdgeNeighbour> edges;
    vector<vector<EdgeNeighbour>> graph(vertices);

    readDataset("GraphdataSet.csv", edges);
    createGraph(graph, edges);

    cout<<"Enter your current location(0 to 100) : ";
    int currentLocation;
    cin>>currentLocation;

    while(currentLocation<0 || currentLocation>100){
        cout<<"Enter valid Location : ";
        cin>>currentLocation;
    }
   findNearestNeighbour(graph, currentLocation, vertices);
}


int main() {
    const int vertices = 101; // Adjust based on your graph size
    vector<EdgeNeighbour> edges;
    vector<vector<EdgeNeighbour>> graph(vertices);

    readDataset("GraphdataSet.csv", edges);
    createGraph(graph, edges);
    findNeighbours(graph, 28, vertices);

    return 0;
}