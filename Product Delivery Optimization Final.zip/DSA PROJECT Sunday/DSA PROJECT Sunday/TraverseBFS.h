#ifndef TRAVERSE_ON_GRAPH_BFS_H
#define TRAVERSE_ON_GRAPH_BFS_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <queue>
#include <string>
using namespace std;


class Edge {
public:
    int src, dest, distance;

    Edge(int src, int dest , int distance){
        this->src = src;
        this->dest = dest;
        this->distance = distance;
    }
};

// Function to read the dataset from a file
void readDataset(const string& filename, vector<Edge>& edges) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open the file!" << endl;
        return;
    }

    string line, word;

    // Skip the header line
    getline(file, line);

    // Read data rows
    while (getline(file, line)) {
        istringstream ss(line);
        vector<string> row;

        // Split the line into values using a comma delimiter
        while (getline(ss, word, ',')) {
            row.push_back(word);
        }

        try {
            int src = stoi(row[0]);
            int dest = stoi(row[1]);
            int distance = stoi(row[2]);
            edges.push_back({src, dest,distance});
        } catch (const exception& e) {
            cerr << "Error converting to integer: " << e.what() << endl;
        }
    }

    file.close();
}

// Function to create a graph as an adjacency list
void createGraph(vector<vector<Edge>>& graph, const vector<Edge>& edges) {
    for (const Edge& e : edges) {
        graph[e.src].push_back(e);
    }
}

void BFS(const vector<vector<Edge>>& graph, int vertices) {
    queue<int> q;              // Queue for BFS
    vector<bool> visitedArray(vertices, false); // Array to track visited nodes

    q.push(0); // Starting point (node 0)

    cout << "BFS Traversal: ";
    while (!q.empty()) {
        int curr = q.front();
        q.pop();

        // Process the current node if it has not been visited
        if (!visitedArray[curr]) {
            cout << curr << " ";   // Step 1: Print the current node
            visitedArray[curr] = true; // Step 2: Mark as visited

            // Step 3: Push all unvisited neighbors into the queue
            for (const Edge& e : graph[curr]) {
                if (!visitedArray[e.dest]) {
                    q.push(e.dest);
                }
            }
        }
    }
    cout << endl;
}


void seePointsOnGraph() {
    const int vertices = 101; // Adjust based on your graph size
    vector<Edge> edges;
    vector<vector<Edge>> graph(vertices);
    // Read dataset and construct the graph
    readDataset("GraphdataSet.csv", edges);
    createGraph(graph, edges);
    // Perform BFS traversal
    BFS(graph, vertices);
}


#endif