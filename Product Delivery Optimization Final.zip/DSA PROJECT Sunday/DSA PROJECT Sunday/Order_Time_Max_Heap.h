#ifndef MAXHEAP_ON_ORDERS_TIME_H
#define MAXHEAP_ON_ORDERS_TIME_H

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
using namespace std;

class OrderForTime {
public:
    string orderID;
    string orderDate;
    string category;
    string orderTime;
    int weight;
    double orderCost;

    OrderForTime(string orderID, string orderDate, string orderTime, string category, int weight) {
        this->orderID = orderID;
        this->orderDate = orderDate;
        this->orderTime = orderTime;
        this->category = category;
        this->weight = weight;
        this->orderCost = calculateCost(weight);
    }

    OrderForTime() {} // Default constructor

    double calculateCost(int weight) {
        return weight * 0.15;
    }
};

class OrderTimeMaxHeap {
private:
    vector<OrderForTime> ordersForTime;

public:
    OrderTimeMaxHeap() {}

    int parent(int i) { return (i - 1) / 2; }
    int leftChild(int i) { return (2 * i) + 1; }
    int rightChild(int i) { return (2 * i) + 2; }

    void swap(OrderForTime& a, OrderForTime& b) {
        OrderForTime temp = a;
        a = b;
        b = temp;
    }

    void insertInMaxHeap(OrderForTime order) {
        ordersForTime.push_back(order);
        int index = ordersForTime.size() - 1;

        while (index > 0 && ordersForTime[parent(index)].orderDate < ordersForTime[index].orderDate) {    
            swap(ordersForTime[index], ordersForTime[parent(index)]);
            index = parent(index);
        }
    }

    void heapify(int index) {
        int largest = index;
        int l_Child = leftChild(index);
        int r_Child = rightChild(index);

        if (l_Child < ordersForTime.size() && ordersForTime[l_Child].orderDate > ordersForTime[largest].orderDate) {
            largest = l_Child;
        }

        if (r_Child < ordersForTime.size() && ordersForTime[r_Child].orderDate > ordersForTime[largest].orderDate) {
            largest = r_Child;
        }

        if (largest != index) {
            swap(ordersForTime[index], ordersForTime[largest]);
            heapify(largest);
        }
    }

    void deleteRoot() {
        if (ordersForTime.empty()) {
            cout << "Heap is empty\n";
            return;
        }

        ordersForTime[0] = ordersForTime.back();
        ordersForTime.pop_back();

        if (!ordersForTime.empty()) {
            heapify(0);
        }
    }

    void printHeap() {
        if (ordersForTime.empty()) {
            cout << "Heap is empty\n";
            return;
        }

        for (const OrderForTime& order : ordersForTime) {
            cout << "ID: " << order.orderID
                << ", Time: " << order.orderTime
                << ", Date: " << order.orderDate
                << ", Cost: " << order.orderCost
                << ", Category: " << order.category
                << ", Weight: " << order.weight << "\n";
        }
        cout << endl;
    }

    int size() const {
        return ordersForTime.size();
    }
};

// Function to read the dataset from a file
vector<OrderForTime> readDatasetForTime(const string& filename) {
    vector<OrderForTime> ordersForTime;
    ifstream file(filename);

    if (!file.is_open()) {
        throw runtime_error("Error: Could not open the file!");
    }

    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        istringstream ss(line);
        vector<string> row;
        string word;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }

        try {
            if (row.size() >= 19) { // Ensure we have enough columns
                string orderID = row[0];
                string orderTime = row[9];
                string orderDate = row[8];
                string category = row[16];
                int weight = stoi(row[18]);

                ordersForTime.push_back(OrderForTime(orderID, orderDate, orderTime, category, weight));
            }
        }
        catch (const exception& e) {
            cerr << "Error processing row: " << e.what() << endl;
            continue;
        }
    }

    file.close();
    return ordersForTime;
}

void createHeap(OrderTimeMaxHeap& heap, const vector<OrderForTime>& ordersForTime) {
    for (const OrderForTime& order : ordersForTime) {
        heap.insertInMaxHeap(order);
    }
}

void seeOrdersBasedOnTime() {
    try {
        OrderTimeMaxHeap heap;
        vector<OrderForTime> ordersForTime = readDatasetForTime("testamazon.csv");
        createHeap(heap, ordersForTime);

        cout << "\nInitial Heap (sorted by orderAmount):\n";
        heap.printHeap();
        
        return;
    }
    catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
        return;
    }
}

#endif
