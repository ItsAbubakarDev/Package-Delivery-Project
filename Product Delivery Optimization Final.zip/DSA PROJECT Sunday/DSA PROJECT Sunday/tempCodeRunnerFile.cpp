#include <iostream>
#include"agent.h"
#include"AgentMaxheap.h"
using namespace std;



int main() {
    cout << "Welcome to the Delivery Portal!" << endl;

    while (true) {
        cout << "\nChoose an option:\n";
        cout << "1. Office Use\n";
        cout << "2. Rider Use\n";
        cout << "3. Order Use\n";
        cout << "4. Path Use\n";
        cout << "5. Customers Use\n";
        cout << "6. Exit\n";

        int mainChoice;
        cout << "Enter your choice (1-6): ";
        cin >> mainChoice;

        switch (mainChoice) {
            case 1: {
                while (true) {
                    cout << "\nOffice Use Options:\n";
                    cout << "1. Retrieve Delivery Agent Data\n";
                    cout << "2. See Highest Rating Agent\n";
                    cout << "3. Go Back\n";

                    int officeChoice;
                    cout << "Enter your choice: ";
                    cin >> officeChoice;

                    switch (officeChoice) {
                        case 1: {
                        cout << "Retrieving Delivery Agent Data...\n";
                        Node* root = get_agent_root();
                        inorderTraversal(root);
                        delete root;  // Don't forget to free memory
                        break;
                        }
                        case 2:
                            cout << "See Highest Rating Agent\n";
                            printheap();
                            break;
                        case 3:
                            goto mainMenu;
                            
                        default:
                            cout << "Invalid choice. Please try again.\n";
                    }
                }
                break;
            }

            case 2: {
                while (true) {
                    cout << "\nRider Use Options:\n";
                    cout << "1. See All Neighbors of the Node\n";
                    cout << "2. See Nearest Neighbor of the Node\n";
                    cout << "3. Find the Distance from the Current Node (A* Algorithm)\n";
                    cout << "4. Go Back\n";

                    int riderChoice;
                    cout << "Enter your choice: ";
                    cin >> riderChoice;

                    switch (riderChoice) {
                        case 1:
                            cout << "Showing All Neighbors...\n";
                            break;
                        case 2:
                            cout << "Showing Nearest Neighbor...\n";
                            break;
                        case 3:
                            cout << "Calculating Distance...\n";
                            break;
                        case 4:
                            goto mainMenu;
                        default:
                            cout << "Invalid choice. Please try again.\n";
                    }
                }
                break;
            }

            case 3: {
                while (true) {
                    cout << "\nOrder Use Options:\n";
                    cout << "1. See All Orders\n";
                    cout << "2. See Orders Based on Category\n";
                    cout << "3. See Priority-Based Orders\n";
                    cout << "4. Go Back\n";

                    int orderChoice;
                    cout << "Enter your choice: ";
                    cin >> orderChoice;

                    switch (orderChoice) {
                        case 1:
                            cout << "Showing All Orders...\n";
                            break;
                        case 2:
                            cout << "Showing Orders by Category...\n";
                            break;
                        case 3:
                            cout << "Showing Priority-Based Orders...\n";
                            break;
                        case 4:
                            goto mainMenu;
                        default:
                            cout << "Invalid choice. Please try again.\n";
                    }
                }
                break;
            }

            case 4: {
                while (true) {
                    cout << "\nPath Use Options:\n";
                    cout << "1. Find the Shortest Path from One Point to Another (A* Algorithm)\n";
                    cout << "2. Find Shortest Path from One Point to All Others (Dijkstra's Algorithm)\n";
                    cout << "3. See Only Necessary Roads of the Graph (Prim's Algorithm)\n";
                    cout << "4. See All the Points of the Graph (BFS)\n";
                    cout << "5. Go Back\n";

                    int pathChoice;
                    cout << "Enter your choice: ";
                    cin >> pathChoice;

                    switch (pathChoice) {
                        case 1:
                            cout << "Finding Shortest Path (A* Algorithm)...\n";
                            break;
                        case 2:
                            cout << "Finding Shortest Path to All (Dijkstra's Algorithm)...\n";
                            break;
                        case 3:
                            cout << "Showing Necessary Roads (Prim's Algorithm)...\n";
                            break;
                        case 4:
                            cout << "Showing All Points (BFS)...\n";
                            break;
                        case 5:
                            goto mainMenu;
                        default:
                            cout << "Invalid choice. Please try again.\n";
                    }
                }
                break;
            }

            case 5: {
                while (true) {
                    cout << "\nCustomer Use Options:\n";
                    cout << "1. Add New Customer\n";
                    cout << "2. Retrieve Customer Data\n";
                    cout << "3. Update Customer Information\n";
                    cout << "4. Go Back\n";

                    int customerChoice;
                    cout << "Enter your choice: ";
                    cin >> customerChoice;

                    switch (customerChoice) {
                        case 1:
                            cout << "Adding New Customer...\n";
                            break;
                        case 2:
                            cout << "Retrieving Customer Data...\n";
                            break;
                        case 3:
                            cout << "Updating Customer Information...\n";
                            break;
                        case 4:
                            goto mainMenu;
                        default:
                            cout << "Invalid choice. Please try again.\n";
                    }
                }
                break;
            }

            case 6:
                cout << "Exiting the Delivery Portal. Have a great day!" << endl;
                return 0;

            default:
                cout << "Bhai, glasses dun?? Bola tha na 1 to 6 choose kro!" << endl;
        }

        mainMenu:;
    }

    return 0;
}
