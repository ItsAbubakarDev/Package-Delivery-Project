#ifndef AGENT_H
#define AGENT_H
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>


using namespace std;

class Node{
    public:
    int agentID;
    string agentName;
    int agentAge;
    double agentRating;
    string agentVehicle;
    int agentDeliveries;

    Node* left;
    Node* right;
    int height;

    Node(int id , string name , int age , double rating , string vehicle , int deliveries){

        this->agentID = id;
        this->agentAge = age;
        this->agentName = name;
        this->agentRating = rating;
        this->agentVehicle = vehicle;
        this->agentDeliveries = deliveries;
        

        height = 1;
        left = NULL;
        right = NULL;
    }
};

int height(Node* n){
    if(n == NULL){
        return 0;
    }
    return n->height;
}

Node* rightRotate(Node* p){
    Node* c = p->left;
    Node* t = c->right;

    //rotating 
    c->right = p;
    p->left = t;

    p->height = max(height(p->left), height(p->right)) + 1;
    c->height = max(height(c->left), height(c->right)) + 1;
    return c;

}

Node* leftRotate(Node* c){
    Node* p = c->right;
    Node* t = p->left;

    //rotating

    p->left = c;
    c->right = t;

    p->height = max(height(p->left), height(p->right)) + 1;
    c->height = max(height(c->left), height(c->right)) + 1;
    return p;
    
}

Node* rotate(Node* root){
    int balance = height(root->left) - height(root->right);

    if(balance >1){
        //left heavy
        if(height(root->left->left) >= height(root->left->right)){
            //left left case 
            return rightRotate(root);
        }
        else{
            //left right case;
            root->left = leftRotate(root->left);
            return rightRotate(root);
        }

    }
    if(balance <-1){
        //right heavy
        if(height(root->right->right)>= height(root->right->left)){
            //right right case
            return leftRotate(root);
        }

        else{
            //right left case
            root->right = rightRotate(root->right);
            return leftRotate(root);
        }
        
    }


    return root;
}

// Function to read the dataset from a file
void readDataset(const string& filename, vector<Node>& nodes) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open the file!" << endl;
        return;
    }

    string line, word;

    // Skip the header line
    getline(file, line);

    // Read data rows
    while (getline(file, line)) {
        istringstream ss(line);
        vector<string> row;

        // Split the line into values using a comma delimiter
        while (getline(ss, word, ',')) {
            row.push_back(word);
        }

        int agentID = 0;
        string agentName;
        int agentAge = 0;
        double agentRating = 0.0;
        string agentVehicle;
        int agentDeliveries = 0;

        try{
            agentID = stoi(row[1]);
            agentAge = stoi(row[3]);
            agentDeliveries = stoi(row[4]);
        }
        catch(exception& e) {
            cerr << "Error converting to integer: " << e.what() << endl;
        }
        

        try {
            agentRating = stod(row[5]);
        } catch (const exception& e) {
            cerr << "Error converting to double: " << e.what() << endl;
        }
            agentVehicle = row[13];
            agentName = row[2];
        try{
            nodes.push_back({agentID, agentName, agentAge, agentRating, agentVehicle,agentDeliveries});
        }    
        catch(const exception &e){
            cerr<<"Error pushing nodes in the vector"<<e.what()<<endl;
        }

    }

    file.close();
}

Node* insertNode(Node* root, Node& node) {
    if (root == NULL) {
        return new Node(node.agentID, node.agentName, node.agentAge, 
                       node.agentRating, node.agentVehicle , node.agentDeliveries);
    }

    if (node.agentID < root->agentID) {
        root->left = insertNode(root->left, node);
    }
    else if (node.agentID > root->agentID) {
        root->right = insertNode(root->right, node);
    }
    else {
        return root; // Duplicate ID, ignore or handle as needed
    }

    // Update height
    root->height = max(height(root->left), height(root->right)) + 1;
    
    return rotate(root);
}

Node* buildTreeFromVector(vector<Node>& nodeVector) {
    Node* root = NULL;
    for (Node& node : nodeVector) {
        root = insertNode(root, node);
    }
    return root;
}



void inorderTraversal(Node* root){
    if(root == NULL){
        return;
    }
    inorderTraversal(root->left);
    cout<<"Agent ID: " << root->agentID<<endl;
    cout<<"Agent Name: " << root->agentName<<endl;
    cout<<"Agent Age: " << root->agentAge<<endl;
    cout<<"Agent Rating: " << root->agentRating<<endl;
    cout<<"Agent Vehicle: " << root->agentVehicle<<endl;
    cout<<"Agent Deliveries: "<<root->agentDeliveries<<endl;
    cout<<endl<<endl;

    inorderTraversal(root->right);
}

void assign_values() {
    vector<Node> nodes;
    readDataset("testamazon.csv", nodes);
    
    Node* root = buildTreeFromVector(nodes);
    inorderTraversal(root);
}

Node* get_agent_root() {
    vector<Node> nodes;
    readDataset("testamazon.csv", nodes);
    return buildTreeFromVector(nodes);
}

#endif