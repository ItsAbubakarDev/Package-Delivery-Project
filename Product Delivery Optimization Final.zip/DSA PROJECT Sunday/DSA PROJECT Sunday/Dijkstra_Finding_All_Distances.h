#ifndef DIJKSTRA_FINDING_DISTANCE_TO_ALL_POINTS_H
#define DIJKSTRA_FINDING_DISTANCE_TO_ALL_POINTS_H
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <queue>
#include <string>
#include<stack>
#include <climits> // For INT_MAX
using namespace std;

int vertices = 101;

class EdgeForDijkstra {
public:
    int src, dest, distanceOfEdge;

    EdgeForDijkstra(int src, int dest, int distanceOfEdge) {
        this->src = src;
        this->dest = dest;
        this->distanceOfEdge = distanceOfEdge;
    }
};

class PairForDijkstra {
public:
    int node;
    int distance;

    PairForDijkstra(int n, int d) {
        node = n;
        distance = d;
    }

    bool operator>(const PairForDijkstra& other) const {
        return distance > other.distance;
    }
};

// Function to print the path from source to destination
void printPath(const vector<int>& parent, int dest) {
    stack<int> path;
    int current = dest;
    
    // Build the path from destination to source
    while (current != -1) {
        path.push(current);
        current = parent[current];
    }
    
    // Print the path
    cout << "Path: ";
    while (!path.empty()) {
        cout << path.top();
        path.pop();
        if (!path.empty()) cout << " -> ";
    }
    cout << endl;
}

void dijkstra(vector<vector<EdgeForDijkstra>> graph, int src) {
    priority_queue<PairForDijkstra, vector<PairForDijkstra>, greater<PairForDijkstra>> pq;
    vector<int> distance(vertices, INT_MAX);
    vector<bool> visitedArray(vertices, false);
    vector<int> parent(vertices, -1); // Keep track of parent nodes
    
    distance[src] = 0;
    pq.push(PairForDijkstra(src, 0));

    while (!pq.empty()) {
        PairForDijkstra curr = pq.top();
        pq.pop();

        int currNode = curr.node;
        if (visitedArray[currNode]) continue;
        visitedArray[currNode] = true;

        for (int i = 0; i < graph[currNode].size(); i++) {
            EdgeForDijkstra e = graph[currNode][i];
            int u = e.src;
            int v = e.dest;

            if (distance[u] + e.distanceOfEdge < distance[v]) {
                distance[v] = distance[u] + e.distanceOfEdge;
                pq.push(PairForDijkstra(v, distance[v]));
                parent[v] = u; // Update parent node
            }
        }
    }

    // Print the shortest distances and paths
    cout << "Shortest distances and paths from source node " << src << ":" << endl;
    for (int i = 0; i < distance.size(); i++) {
        if (i != src && distance[i] != INT_MAX) { // Only print reachable nodes
            cout << "Location " << i << " has shortest distance: " << distance[i] << endl;
            printPath(parent, i);
            cout << "------------------------" << endl;
        } else if (i != src && distance[i] == INT_MAX) {
            cout << "Location " << i << ": INF (No path exists)" << endl;
            cout << "------------------------" << endl;
        }
    }
}

void readDatasetForDijkstra(const string& filename, vector<EdgeForDijkstra>& edges) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open the file!" << endl;
        return;
    }

    string line, word;
    getline(file, line);

    while (getline(file, line)) {
        istringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }

        try {
            int src = stoi(row[0]);
            int dest = stoi(row[1]);
            int distance = stoi(row[2]);
            edges.push_back({src, dest, distance});
        } catch (const exception& e) {
            cerr << "Error converting to integer: " << e.what() << endl;
        }
    }

    file.close();
}

void createGraphForDijkstra(vector<vector<EdgeForDijkstra>>& graph, const vector<EdgeForDijkstra>& edges) {
    for (const EdgeForDijkstra& e : edges) {
        graph[e.src].push_back(e);
    }
}

void seeAllDistancesFromCurrentLocation() {
    vector<EdgeForDijkstra> edges;
    vector<vector<EdgeForDijkstra>> graph(vertices);

    readDatasetForDijkstra("GraphdataSet.csv", edges);
    createGraphForDijkstra(graph, edges);

    cout << "Kindly Enter your current Location: ";
    int currLocation;
    cin >> currLocation;
    while (currLocation < 0 || currLocation > 100) {
        cout << "Kindly Enter your current Location: ";
        cin >> currLocation;
    }
    dijkstra(graph, currLocation);
}

void shortestPathBetweenTwoLocationsHelper(vector<vector<EdgeForDijkstra>> graph, int src, int destination) {
    // Check for valid input
    if (src < 0 || src >= vertices || destination < 0 || destination >= vertices) {
        cout << "Invalid source or destination location" << endl;
        return;
    }

    priority_queue<PairForDijkstra, vector<PairForDijkstra>, greater<PairForDijkstra>> pq;
    vector<int> distance(vertices, INT_MAX);
    vector<bool> visitedArray(vertices, false);
    vector<int> parent(vertices, -1); // Keep track of parent nodes

    distance[src] = 0;
    pq.push(PairForDijkstra(src, 0));

    bool destinationFound = false;

    while (!pq.empty()) {
        PairForDijkstra curr = pq.top();
        pq.pop();

        int currNode = curr.node;
        if (visitedArray[currNode]) continue;
        visitedArray[currNode] = true;

        // If we've reached our destination, we can stop
        if (currNode == destination) {
            destinationFound = true;
            break;
        }

        for (const EdgeForDijkstra& e : graph[currNode]) {
            int v = e.dest;

            if (!visitedArray[v] && distance[currNode] + e.distanceOfEdge < distance[v]) {
                distance[v] = distance[currNode] + e.distanceOfEdge;
                pq.push(PairForDijkstra(v, distance[v]));
                parent[v] = currNode; // Store the current node as parent
            }
        }
    }

    // Print result only for the destination
    if (destinationFound && distance[destination] != INT_MAX) {
        cout << "Shortest path from location " << src << " to location " << destination << ":" << endl;
        cout << "Total distance: " << distance[destination] << endl;
        printPath(parent, destination);
        cout << "------------------------" << endl;
    }
    else {
        cout << "No path exists between location " << src << " and location " << destination << endl;
        cout << "------------------------" << endl;
    }
}

void seeDistanceBetweenTwoPoints() {
    vector<EdgeForDijkstra> edges;
    vector<vector<EdgeForDijkstra>> graph(vertices);

    readDatasetForDijkstra("GraphdataSet.csv", edges);
    createGraphForDijkstra(graph, edges);

    cout << "Enter source node: ";
    int src;
    cin >> src;
    cout << "Enter destination node: ";
    int destination;
    cin >> destination;
    while (src < 0 || src > 100) {
        cout << "Kindly Enter your source node: ";
        cin >> src;

    } 
    while(destination < 0 || destination > 100) {
        cout << "Kindly Enter your destination node : ";
        cin >> destination;
    }
    shortestPathBetweenTwoLocationsHelper(graph, src , destination);
}


#endif
