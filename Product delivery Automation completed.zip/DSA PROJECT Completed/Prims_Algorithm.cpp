#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <queue>
#include <vector>
using namespace std;

// Number of vertices in the graph
int vertices = 101;

// Structure to represent an edge
class EdgeForPrim {
public:
    int src, dest, distance;

    EdgeForPrim(int src, int dest , int distance){
        this->src = src;
        this->dest = dest;
        this->distance = distance;
    }
};

// Class representing a pair of node and its cost
class PairForPrim {
public:
    int node;
    int cost;

    PairForPrim(int n, int c) {
        this->node = n;
        this->cost = c;
    }

    // Overloading the '>' operator for priority queue to act as a min-heap
    bool operator>(const PairForPrim& other) const {
        return cost > other.cost;
    }
};

// Function to create a graph as an adjacency list
void createGraph(vector<vector<EdgeForPrim>>& graph, const vector<EdgeForPrim>& edges) {
    for (const EdgeForPrim& e : edges) {
        graph[e.src].push_back(e);
    }
}

// Function to read the dataset from a file
void readDatasetForPrims(const string& filename, vector<EdgeForPrim>& edges) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open the file!" << endl;
        return;
    }

    string line, word;

    // Skip the header line
    getline(file, line);

    // Read data rows
    while (getline(file, line)) {
        istringstream ss(line);
        vector<string> row;

        // Split the line into values using a comma delimiter
        while (getline(ss, word, ',')) {
            row.push_back(word);
        }

        try {
            int src = stoi(row[0]);
            int dest = stoi(row[1]);
            int distance = stoi(row[2]);
            edges.push_back({src, dest,distance});
        } catch (const exception& e) {
            cerr << "Error converting to integer: " << e.what() << endl;
        }
    }

    file.close();
}



// Function to implement Prim's Algorithm and calculate the minimum spanning tree (MST) cost
void primAlgorithm(const vector<vector<EdgeForPrim>>& graph) {
    priority_queue<PairForPrim, vector<PairForPrim>, greater<PairForPrim>> pq;

    // Array to track visited nodes
    vector<bool> visited(vertices, false);

    // Array to store the parent of each node
    vector<int> parent(vertices, -1);

    // Start with the first node (node 0) with cost 0
    pq.push(PairForPrim(0, 0));

    int finalCost = 0; // Total cost of the MST

    while (!pq.empty()) {
        PairForPrim curr = pq.top();
        pq.pop();

        int currNode = curr.node;

        // If the node is not visited, include it in the MST
        if (!visited[currNode]) {
            visited[currNode] = true;

            finalCost += curr.cost;

            // Add all adjacent edges to the priority queue
            for (int i = 0; i < graph[currNode].size(); i++) {
                EdgeForPrim e = graph[currNode][i];
                if (!visited[e.dest]) {
                    pq.push(PairForPrim(e.dest, e.distance));
                    // Update the parent of the destination node
                    parent[e.dest] = currNode;
                }
            }
        }
    }

    // Output the total cost of the MST
    cout << "Minimum cost of MST: " << finalCost << endl;

    // Print the edges in the MST
    cout << "Edges in the MST:" << endl;
    for (int i = 1; i < vertices; i++) {
        if (parent[i] != -1) {
            cout << parent[i] << " --> " << i << "-->";
        }
    }
}

void primsalgorithm() {
    vector<EdgeForPrim> edges;
    
    // Read the dataset from file
    // Note: Replace "network_data.csv" with your actual dataset filename
    readDatasetForPrims("GraphdataSet.csv", edges);
    
    // Create adjacency list representation of the graph
    vector<vector<EdgeForPrim>> graph(vertices);
    createGraph(graph, edges);

    
    // Run Prim's Algorithm
    primAlgorithm(graph);
    
}

int main() {
    vector<EdgeForPrim> edges;
    
    // Read the dataset from file
    // Note: Replace "network_data.csv" with your actual dataset filename
    readDatasetForPrims("GraphdataSet.csv", edges);
    
    // Create adjacency list representation of the graph
    vector<vector<EdgeForPrim>> graph(vertices);
    createGraph(graph, edges);

    
    // Run Prim's Algorithm
    primAlgorithm(graph);
    
    return 0;
}
