#include <iostream>
#include"agent.h"
#include"AgentMaxheap.h"
#include "NeighboursOfPoint.h"
#include"TraverseBFS.h"
#include"MaxHeap_Orders_Cost.h"
#include "Order_Time_Max_Heap.h"
#include"Orders_In_AVL.h"
#include "Prims.h"
using namespace std;

MaxHeap globalHeap;

void printheap() {
    vector<Agent> agents;
    try {
        agents = readDataset("testamazon.csv");
        for (const Agent& agent : agents) {
            globalHeap.insertInMaxHeap(agent);
        }
        globalHeap.printHeap();
    } catch (const exception& e) {
        cerr << "Error loading agent data: " << e.what() << endl;
    }
}

int main() {
    cout << "Welcome to the Delivery Portal!" << endl;

    while (true) {
        cout << "\nChoose an option:\n";
        cout << "1. Office Operations\n";
        cout << "2. Rider Tools\n";
        cout << "3. Order Management\n";
        cout << "4. Pathfinding Algorithms\n";
        cout << "5. Customer Management\n";
        cout << "6. Exit\n";

        int mainChoice;
        cout << "Enter your choice (1-6): ";
        cin >> mainChoice;

        switch (mainChoice) {
            case 1: {
                while (true) {
                    cout << "\nOffice Options:\n";
                    cout << "1. View Delivery Agent Data\n";
                    cout << "2. Display Top-Rated Delivery Agent\n";
                    cout << "3. Return to Main Menu\n";

                    int officeChoice;
                    cout << "Enter your choice: ";
                    cin >> officeChoice;

                    switch (officeChoice) {
                        case 1: {
                        cout << "Fetching delivery agent data...\n";
                        Node* root = get_agent_root();
                        inorderTraversal(root);
                        delete root;  // Don't forget to free memory
                        break;
                        }
                        case 2:
                            cout << "Displaying the top-rated delivery agent...\n";
                            printheap();
                            break;
                    
                        case 3:
                            goto mainMenu;
                        default:
                            cout << "Invalid selection. Please choose a valid option.\n";
                    }
                }
                break;
            }

            case 2: {
                while (true) {
                    cout << "\nRider Tools:\n";
                    cout << "1. View All Neighboring Nodes\n";
                    cout << "2. Find Nearest Neighbor\n";
                    cout << "3. Calculate Distance Using A* Algorithm\n";
                    cout << "4. Return to Main Menu\n";

                    int riderChoice;
                    cout << "Enter your choice: ";
                    cin >> riderChoice;

                    switch (riderChoice) {
                        case 1:
                            cout << "Displaying all neighboring nodes...\n";
                            getNeighbours();
                           break;
                        case 2:
                            cout << "Finding the nearest neighbor...\n";
                            break;
                        case 3:
                            cout << "Calculating distance using A* algorithm...\n";
                            break;
                        case 4:
                            goto mainMenu;
                        default:
                            cout << "Invalid selection. Please choose a valid option.\n";
                    }
                }
                break;
            }

            case 3: {
                while (true) {
                    cout << "\nOrder Management:\n";
                    cout << "1. View All Orders\n";
                    cout << "2. Filter Orders by Category\n";
                    cout << "3. Display Cost_Priority-Based Orders\n";
                    cout << "4. Display Time_Priority_Based Orders\n";
                    cout << "5. Return to Main Menu\n";

                    int orderChoice;
                    cout << "Enter your choice: ";
                    cin >> orderChoice;

                    switch (orderChoice) {
                        case 1:
                            cout << "Displaying all orders...\n";
                            OrdersInAVLTree();
                            break;
                        case 2:
                            cout << "Filtering orders by category...\n";
                            break;
                        case 3:
                            cout << "Displaying Cost-priority-based orders...\n";
                            seeOrdersBasedOnCost();
                            break;
                        case 4:
                            cout << "Displaying Time-priority-based orders...\n";
                            seeOrdersBasedOnTime();
                            break;
                        case 5:
                            goto mainMenu;
                        default:
                            cout << "Invalid selection. Please choose a valid option.\n";
                    }
                }
                break;
            }

            case 4: {
                while (true) {
                    cout << "\nPathfinding Algorithms:\n";
                    cout << "1. Shortest Path Between Two Points (A* Algorithm)\n";
                    cout << "2. Shortest Path to All Points (Dijkstra's Algorithm)\n";
                    cout << "3. Display Minimum Spanning Tree (Prim's Algorithm)\n";
                    cout << "4. Display All Points in the Graph (BFS)\n";
                    cout << "5. Return to Main Menu\n";

                    int pathChoice;
                    cout << "Enter your choice: ";
                    cin >> pathChoice;

                    switch (pathChoice) {
                        case 1:
                            cout << "Calculating shortest path using A* algorithm...\n";
                            break;
                        case 2:
                            cout << "Finding shortest paths to all points using Dijkstra's algorithm...\n";
                            break;
                        case 3:
                            cout << "Displaying minimum spanning tree using Prim's algorithm...\n";
                            primsalgorithm();
                            break;
                        case 4:
                            cout << "Displaying all points in the graph using BFS...\n";
                            seePointsOnGraph();
                            break;
                        case 5:
                            goto mainMenu;
                        default:
                            cout << "Invalid selection. Please choose a valid option.\n";
                    }
                }
                break;
            }

            case 5: {
                cout << "\nCustomer Management:\n";
                    cout << "1. Add a New Customer\n";
                    cout << "2. Retrieve Customer Details\n";
                    cout << "3. Update Customer Information\n";
                    cout << "4. Return to Main Menu\n";

                    int customerChoice;
                    cout << "Enter your choice: ";
                    cin >> customerChoice;

                    switch (customerChoice) {
                        case 1:
                            cout << "Adding a new customer...\n";
                            break;
                        case 2:
                            cout << "Retrieving customer details...\n";
                            break;
                        case 3:
                            cout << "Updating customer information...\n";
                            break;
                        case 4:
                            goto mainMenu;
                        default:
                            cout << "Invalid selection. Please choose a valid option.\n";
                    }
                break;
            }

            case 6:
                cout << "Thank you for using the Delivery Portal. Have a great day!\n";
                return 0;

            default:
                cout << "Invalid input. Please select an option between 1 and 6.\n";
        }

        mainMenu:;
    }

    return 0;
}