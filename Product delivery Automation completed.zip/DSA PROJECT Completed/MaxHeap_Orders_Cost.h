#ifndef MAXHEAP_ON_ORDERS_COST_H
#define MAXHEAP_ON_ORDERS_COST_H
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
using namespace std;

class Order {
public:
    string orderID;
    string orderDate;
    string category;
    string orderTime;
    int weight;
    double orderCost;

    Order(string orderID, string orderDate, string orderTime, string category, int weight) {
        this->orderID = orderID;
        this->orderDate = orderDate;
        this->orderTime = orderTime;
        this->category = category;
        this->weight = weight;
        this->orderCost = calculateCost(weight);
    }

    Order() {} // Default constructor

    double calculateCost(int weight) {
        return weight * 0.15;
    }
};

class OrderCostMaxHeap {
private:
    vector<Order> orders;

public:
    OrderCostMaxHeap() {}

    int parent(int i) { return (i - 1) / 2; }
    int leftChild(int i) { return (2 * i) + 1; }
    int rightChild(int i) { return (2 * i) + 2; }

    void swap(Order& a, Order& b) {
        Order temp = a;
        a = b;
        b = temp;
    }

    void insertInMaxHeap(Order order) {
        orders.push_back(order);
        int index = orders.size() - 1;

        while (index > 0 && orders[parent(index)].orderCost < orders[index].orderCost) {
            swap(orders[index], orders[parent(index)]);
            index = parent(index);
        }
    }

    void heapify(int index) {
        int largest = index;
        int l_Child = leftChild(index);
        int r_Child = rightChild(index);

        if (l_Child < orders.size() && orders[l_Child].orderCost > orders[largest].orderCost) {
            largest = l_Child;
        }

        if (r_Child < orders.size() && orders[r_Child].orderCost > orders[largest].orderCost) {
            largest = r_Child;
        }

        if (largest != index) {
            swap(orders[index], orders[largest]);
            heapify(largest);
        }
    }

    void deleteRoot() {
        if (orders.empty()) {
            cout << "Heap is empty\n";
            return;
        }

        orders[0] = orders.back();
        orders.pop_back();

        if (!orders.empty()) {
            heapify(0);
        }
    }

    void printHeap() {
        if (orders.empty()) {
            cout << "Heap is empty\n";
            return;
        }

        for (const Order& order : orders) {
            cout << "ID: " << order.orderID
                << ", Time: " << order.orderTime
                << ", Date: " << order.orderDate
                << ", Cost: " << order.orderCost
                << ", Category: " << order.category
                << ", Weight: " << order.weight << "\n";
        }
        cout << endl;
    }

    int size() const {
        return orders.size();
    }
};

// Function to read the dataset from a file
vector<Order> readDatasetforCost(const string& filename) {
    vector<Order> orders;
    ifstream file(filename);

    if (!file.is_open()) {
        throw runtime_error("Error: Could not open the file!");
    }

    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        istringstream ss(line);
        vector<string> row;
        string word;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }

        try {
            if (row.size() >= 19) { // Ensure we have enough columns
                string orderID = row[0];
                string orderTime = row[9];
                string orderDate = row[8];
                string category = row[16];
                int weight = stoi(row[18]);

                orders.push_back(Order(orderID, orderDate, orderTime, category, weight));
            }
        }
        catch (const exception& e) {
            cerr << "Error processing row: " << e.what() << endl;
            continue;
        }
    }

    file.close();
    return orders;
}

void createHeap(OrderCostMaxHeap& heap, const vector<Order>& orders) {
    for (const Order& order : orders) {
        heap.insertInMaxHeap(order);
    }
}

void seeOrdersBasedOnCost() {
    try {
        OrderCostMaxHeap heap;
        vector<Order> orders = readDatasetforCost("testamazon.csv");
        createHeap(heap, orders);

        cout << "\nInitial Heap (sorted by orderAmount):\n";
        heap.printHeap();
        return ;
    }
    catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
        return ;
    }
}
#endif