#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <stdexcept>

using namespace std;

class Agent {
public:
    int agentID;
    string agentName;
    int agentAge;
    double agentRating;
    string agentVehicle;
    int agentDeliveries;

    Agent(int id, string name, int age, double rating, string vehicle, int deliveries) {
        agentID = id;
        agentAge = age;
        agentName = name;
        agentRating = rating;
        agentVehicle = vehicle;
        agentDeliveries = deliveries;
    }
};

class MaxHeap {
private:
    vector<Agent> agents;  // Changed to vector of Agents instead of int array
    
public:
    // Constructor no longer needs size parameter since we're using vector
    MaxHeap() {}

    int parent(int i) { return (i - 1) / 2; }
    int leftChild(int i) { return (2 * i) + 1; }
    int rightChild(int i) { return (2 * i) + 2; }

    // Modified to swap Agents instead of ints
    void swap(Agent& a, Agent& b) {
        Agent temp = a;
        a = b;
        b = temp;
    }

    void insertInMaxHeap(Agent agent) {
        agents.push_back(agent);
        int index = agents.size() - 1;

        // Modified comparison to use agentRating instead of direct comparison
        while (index > 0 && agents[parent(index)].agentRating < agents[index].agentRating) {
            swap(agents[index], agents[parent(index)]);
            index = parent(index);
        }
    }

    void heapify(int index) {
        int largest = index;
        int l_Child = leftChild(index);
        int r_Child = rightChild(index);

        if (l_Child < agents.size() && agents[l_Child].agentRating > agents[largest].agentRating) {
            largest = l_Child;
        }

        if (r_Child < agents.size() && agents[r_Child].agentRating > agents[largest].agentRating) {
            largest = r_Child;
        }

        if (largest != index) {
            swap(agents[index], agents[largest]);
            heapify(largest);
        }
    }

    void deleteRoot() {
        if (agents.empty()) {
            cout << "Heap is empty\n";
            return;
        }

        agents[0] = agents.back();
        agents.pop_back();

        if (!agents.empty()) {
            heapify(0);
        }
    }

    void printHeap() {
        if (agents.empty()) {
            cout << "Heap is empty\n";
            return;
        }

        for (const Agent& agent : agents) {
            cout << "ID: " << agent.agentID 
                 << ", Name: " << agent.agentName 
                 << ", Rating: " << agent.agentRating << "\n";
        }
        cout << endl;
    }

    int size() const {
        return agents.size();
    }
};

// Function to read the dataset from a file
vector<Agent> readDataset(const string& filename) {
    vector<Agent> agents;
    ifstream file(filename);
    
    if (!file.is_open()) {
        throw runtime_error("Error: Could not open the file!");
    }

    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        istringstream ss(line);
        vector<string> row;
        string word;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }

        try {
            int agentID = stoi(row[1]);
            string agentName = row[2];
            int agentAge = stoi(row[3]);
            int agentDeliveries = stoi(row[4]);
            double agentRating = stod(row[5]);
            string agentVehicle = row[13];

            agents.emplace_back(agentID, agentName, agentAge, agentRating, agentVehicle, agentDeliveries);
        }
        catch (const exception& e) {
            cerr << "Error processing row: " << e.what() << endl;
            continue;
        }
    }

    file.close();
    return agents;
}


void createHeap(MaxHeap heap , vector<Agent> agents){
    // Insert all agents into the heap
        for (const Agent& agent : agents) {
            heap.insertInMaxHeap(agent);
        }
}

int main() {
    MaxHeap heap;
    vector<Agent> agents = readDataset("testamazon.csv");
    createHeap(heap,agents);   

        // Print initial heap
        cout << "\nInitial Heap (sorted by rating):\n";
        heap.printHeap();

        // Delete the highest rated agent
        cout << "\nDeleting highest rated agent...\n";
        heap.deleteRoot();

        // Print updated heap
        cout << "\nUpdated Heap:\n";
        heap.printHeap();


    return 0;
}