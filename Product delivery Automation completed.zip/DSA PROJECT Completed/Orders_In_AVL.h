#ifndef ALL_ORDERS_IN_AVL_H
#define ALL_ORDERS_IN_AVL_H

#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

class NodeForOrders{
public:

    string orderID;
    string orderDate;    
    string orderTime;
    string orderCategory;
    int orderWeight;
    double orderCost;

    NodeForOrders* left;
    NodeForOrders* right;
    int height;

    NodeForOrders(string orderID, string orderDate, string orderTime, string category,int weight, double cost) {
        this->orderID = orderID;
        this->orderDate = orderDate;
        this->orderTime = orderTime;
        this->orderCategory = category;
        this->orderWeight = weight;
        this->orderCost = cost;

        this->left = nullptr;
        this->right = nullptr;
        this->height = 1;
    }

};

int height(NodeForOrders* n) {
    if (n == nullptr) {
        return 0;
    }
    return n->height; 
}

NodeForOrders* rotateRight(NodeForOrders* parent) {
    NodeForOrders* child = parent->left;
    NodeForOrders* temp = child->right;

    child->right = parent;
    parent->left = temp;

    parent->height = max(height(parent->left), height(parent->right)) + 1;
    child->height = max(height(child->left), height(child->right)) + 1;
    return child;
}

NodeForOrders* rotateLeft(NodeForOrders* child){
    NodeForOrders* parent = child->right;
    NodeForOrders* temp = parent->left;

    parent->left = child;
    child->right = temp;

    parent->height = max(height(parent->left), height(parent->right)) + 1;
    child->height = max(height(child->left), height(child->right)) + 1;
    return parent;
}

NodeForOrders* rotate(NodeForOrders* root){
    int balance = height(root->left) - height(root->right);

    if(balance >1){
        //left heavy
        if(height(root->left->left) >= height(root->left->right)){
            //left left case 
            return rotateRight(root);
        }
        else{
            //left right case;
            root->left = rotateLeft(root->left);
            return rotateRight(root);
        }

    }
    if(balance <-1){
        //right heavy
        if(height(root->right->right)>= height(root->right->left)){
            //right right case
            return rotateLeft(root);
        }

        else{
            //right left case
            root->right = rotateRight(root->right);
            return rotateLeft(root);
        }
    }
    return root;
}

// Function to read the dataset from a file
void readDatasetToDisplayOrders(const string& filename, vector<NodeForOrders>& orders) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open the file!" << endl;
        return;
    }

    string line, word;

    // Skip the header line
    getline(file, line);

    // Read data rows
    while (getline(file, line)) {
        istringstream ss(line);
        vector<string> row;

        // Split the line into values using a comma delimiter
        while (getline(ss, word, ',')) {
            row.push_back(word);
        }

        string orderID;
        string orderDate;    
        string orderTime;
        string orderCategory;
        int orderWeight;
        double orderCost;

        orderID = row[0];
        orderDate = row[8];
        orderTime = row[9];
        orderCategory = row[16];

        try{
            orderWeight = stoi(row[18]);
        }
        catch(exception& e) {
            cerr << "Error converting to integer: " << e.what() << endl;
        }

        try {
            orderCost = stod(row[19]);
        } catch (const exception& e) {
            cerr << "Error converting to double: " << e.what() << endl;
        }

        try{
            orders.push_back({orderID, orderDate, orderTime, orderCategory, orderWeight, orderCost});
        }    
        catch(const exception &e){
            cerr<<"Error pushing nodes in the vector"<<e.what()<<endl;
        }

    }

    file.close();
}


NodeForOrders* insertNode(NodeForOrders* root, NodeForOrders& newOrder) {
    if (root == NULL) {
        return new NodeForOrders(newOrder.orderID, newOrder.orderDate, newOrder.orderTime, newOrder.orderCategory, newOrder.orderWeight, newOrder.orderCost);
    }

    if ((newOrder.orderDate < root->orderDate) || ((newOrder.orderDate == root->orderDate) && (newOrder.orderTime < root->orderTime)) ) {
        root->left = insertNode(root->left, newOrder);
    }
    else if ((newOrder.orderDate > root->orderDate) || ((newOrder.orderDate == root->orderDate) && (newOrder.orderTime > root->orderTime)) ) {
        root->right = insertNode(root->right, newOrder);
    }
    else {
        return root;
    }

    // Update height
    root->height = max(height(root->left), height(root->right)) + 1;
    
    return rotate(root);
}

NodeForOrders* buildTreeFromVector(vector<NodeForOrders> &orderVector) {
    NodeForOrders* root = NULL;
    for (NodeForOrders& node : orderVector) {
        root = insertNode(root, node);
    }
    return root;
}


void inorderTraversal(NodeForOrders* root){
    if(root == NULL){
        return;
    }
    inorderTraversal(root->left);
    cout<<"Order ID: " << root->orderID<<endl;
    cout<<"Order Date: " << root->orderDate<<endl;
    cout<<"Order Time: " << root->orderTime<<endl;
    cout<<"Category: " << root->orderCategory<<endl;
    cout<<"Order Weight: " << root->orderWeight<<endl;
    cout<<"Order Cost: "<<root->orderCost<<endl;
    cout<<endl<<endl;
    inorderTraversal(root->right);
}

void OrdersInAVLTree() {
    vector<NodeForOrders> orders;
    readDatasetToDisplayOrders("testamazon.csv", orders);
    
    NodeForOrders* root = buildTreeFromVector(orders);
    inorderTraversal(root);
    
    return;
}

#endif